package com.example.prac2_iangironcle;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.opengl.GLSurfaceView.Renderer;
import android.opengl.GLU;

public class MyOpenGLRenderer implements Renderer {

	private Light light;
	private Object object3D;
	private Object colum;
	private Barra_Princ puerta;
	private Barra_Princ suelo;
	private Barra_Princ techo;
	private Barra_Princ pared1;
	private Barra_Princ pared2;
	private Barra_Princ pared3;
	private Barra_Princ pared4;
	private Barra_Princ barraPrincText;
	private Barra_Princ cabezaText;
	private Barra_Princ n1Text;
	private Barra_Princ n2Text;
	private Barra_Princ n3Text;
	private Barra_Princ n4Text;
	private Barra_Princ n5Text;
	private Barra_Princ n6Text;
	private Barra_Princ n7Text;
	private Barra_Princ n8Text;
	private Barra_Princ arms;
	private Barra_Princ arma;
	private Barra_Princ aux;
	private Barra_Princ n1;
	private Barra_Princ n2;
	private Barra_Princ n3;
	private Barra_Princ n4;
	private Barra_Princ n5;
	private Barra_Princ n6;
	private Barra_Princ n7;
	private Barra_Princ n8;
	private Barra_Princ n9;
	private Barra_Princ n10;
	private Barra_Princ n11;
	private Barra_Princ n12;
	private Barra_Princ n13;
	private Barra_Princ n14;
	private Barra_Princ n15;
	private Barra_Princ n16;
	private Barra_Princ n17;
	private Barra_Princ n18;
	private Barra_Princ n19;
	private Barra_Princ n20;


	public float getzCam() {
		return zCam;
	}

	public void setzCam(float zCam) {
		this.zCam = zCam;
	}

	public float gettouch() {
		return touch;
	}

	public void settouch(float touch) {
		this.touch = touch;
	}
	public float getAngle() {
		return angle;
	}

	public void setAngle(float angle) {
		this.angle = angle;
	}
	private float zCam = 0;
	private float touch = 1;

	private float angle = 0;
	private float mov = 0;
	float tiempo = 0.0f;

	private Context context;
	private int width;

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	private int height;

	private float[] originalLightPosition = {0.0f, 2f, 2f, 0.0f};
	private float[] transformedLightPosition = new float[4];

	public MyOpenGLRenderer(Context context){
		this.context = context;
	}

	public void onSurfaceCreated(GL10 gl, EGLConfig config) {

		gl.glClearColor(0.0f, 0.0f, 0.0f, 0.1f);
		float texCoords[];
		//diferencia desplazamiento de numeros rojos = 47 en la izquierda
		//diferencia desplazamiento de numeros amarillos = 16

		this.object3D = new Object(context, R.raw.plano);
		this.colum = new Object(context, R.raw.columna);

		puerta = new Barra_Princ();
		suelo = new Barra_Princ();
		techo = new Barra_Princ();
		pared1 = new Barra_Princ();
		pared2 = new Barra_Princ();
		pared3 = new Barra_Princ();
		pared4 = new Barra_Princ();
		barraPrincText = new Barra_Princ();
		cabezaText = new Barra_Princ();
		n1Text = new Barra_Princ();
		n2Text = new Barra_Princ();
		n3Text = new Barra_Princ();
		n4Text = new Barra_Princ();
		n5Text = new Barra_Princ();
		n6Text = new Barra_Princ();
		n7Text = new Barra_Princ();
		n8Text = new Barra_Princ();
		arms = new Barra_Princ();
		arma = new Barra_Princ();
		aux = new Barra_Princ();
		n1 = new Barra_Princ();
		n2 = new Barra_Princ();
		n3 = new Barra_Princ();
		n4 = new Barra_Princ();
		n5 = new Barra_Princ();
		n6 = new Barra_Princ();
		n7 = new Barra_Princ();
		n8 = new Barra_Princ();
		n9 = new Barra_Princ();
		n10 = new Barra_Princ();
		n11 = new Barra_Princ();
		n12 = new Barra_Princ();
		n13 = new Barra_Princ();
		n14 = new Barra_Princ();
		n15 = new Barra_Princ();
		n16 = new Barra_Princ();
		n17 = new Barra_Princ();
		n18 = new Barra_Princ();
		n19 = new Barra_Princ();
		n20 = new Barra_Princ();

		object3D.loadTexture(gl, context, R.raw.doomenemi);
		colum.loadTexture(gl, context, R.raw.colum);
		barraPrincText.loadTexture(gl, context, R.raw.doomhud);

		puerta.loadTexture(gl,context, R.raw.puerta);
		texCoords = new float[]{
				-1f, -1f, 0.0f,  // Vértice inferior izquierdo
				-1f,  1f, 0.0f,  // Vértice superior izquierdo
				1f,   1f, 0.0f,  // Vértice superior derecho
				1f,  -1f, 0.0f   // Vértice inferior derecho
		};
		puerta.setvertices(texCoords);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 1f,  // A. left botom
				0f, 0f,  // B. left top
				1f, 0f,   // D. right botom
				1f, 1f,  // C. right top
		};
		puerta.setTexCoords(texCoords);

		pared1.loadTexture(gl,context, R.raw.pared);
		texCoords = new float[]{
				-20f, -10f, 0.0f,  // Vértice inferior izquierdo
				-20f,  10f, 0.0f,  // Vértice superior izquierdo
				20f,   10f, 0.0f,  // Vértice superior derecho
				20f,  -10f, 0.0f   // Vértice inferior derecho
		};
		pared1.setvertices(texCoords);

		texCoords = new float[]{
				0.0f, 10.0f,  // A. left bottom (repitiendo la textura 2 veces en eje Y)
				0.0f, 0.0f,  // B. left top
				10.0f, 0.0f,  // C. right top
				10.0f, 10.0f   // D. right bottom (repitiendo la textura 2 veces en eje X)
		};
		pared1.setTexCoords(texCoords);

		pared2.loadTexture(gl,context, R.raw.pared);
		texCoords = new float[]{
				-20f, -10f, 0.0f,  // Vértice inferior izquierdo
				-20f,  10f, 0.0f,  // Vértice superior izquierdo
				20f,   10f, 0.0f,  // Vértice superior derecho
				20f,  -10f, 0.0f   // Vértice inferior derecho
		};
		pared2.setvertices(texCoords);

		texCoords = new float[]{
				0.0f, 10.0f,  // A. left bottom (repitiendo la textura 2 veces en eje Y)
				0.0f, 0.0f,  // B. left top
				10.0f, 0.0f,  // C. right top
				10.0f, 10.0f   // D. right bottom (repitiendo la textura 2 veces en eje X)
		};
		pared2.setTexCoords(texCoords);

		pared3.loadTexture(gl,context, R.raw.pared);
		texCoords = new float[]{
				-20f, -10f, 0.0f,  // Vértice inferior izquierdo
				-20f,  10f, 0.0f,  // Vértice superior izquierdo
				20f,   10f, 0.0f,  // Vértice superior derecho
				20f,  -10f, 0.0f   // Vértice inferior derecho
		};
		pared3.setvertices(texCoords);

		texCoords = new float[]{
				0.0f, 10.0f,  // A. left bottom (repitiendo la textura 2 veces en eje Y)
				0.0f, 0.0f,  // B. left top
				10.0f, 0.0f,  // C. right top
				10.0f, 10.0f   // D. right bottom (repitiendo la textura 2 veces en eje X)
		};
		pared3.setTexCoords(texCoords);

		pared4.loadTexture(gl,context, R.raw.pared);
		texCoords = new float[]{
				-20f, -10f, 0.0f,  // Vértice inferior izquierdo
				-20f,  10f, 0.0f,  // Vértice superior izquierdo
				20f,   10f, 0.0f,  // Vértice superior derecho
				20f,  -10f, 0.0f   // Vértice inferior derecho
		};
		pared4.setvertices(texCoords);

		texCoords = new float[]{
				0.0f, 10.0f,  // A. left bottom (repitiendo la textura 2 veces en eje Y)
				0.0f, 0.0f,  // B. left top
				10.0f, 0.0f,  // C. right top
				10.0f, 10.0f   // D. right bottom (repitiendo la textura 2 veces en eje X)
		};
		pared4.setTexCoords(texCoords);

		suelo.loadTexture(gl,context, R.raw.suelo);
		texCoords = new float[]{
				-30f, -30f, 0.0f,  // Vértice inferior izquierdo
				-30f,  30f, 0.0f,  // Vértice superior izquierdo
				30f,   30f, 0.0f,  // Vértice superior derecho
				30f,  -30f, 0.0f   // Vértice inferior derecho
		};
		suelo.setvertices(texCoords);

		texCoords = new float[]{
				0.0f, 30.0f,  // A. left bottom (repitiendo la textura 2 veces en eje Y)
				0.0f, 0.0f,  // B. left top
				30.0f, 0.0f,  // C. right top
				30.0f, 30.0f   // D. right bottom (repitiendo la textura 2 veces en eje X)
		};
		suelo.setTexCoords(texCoords);

		techo.loadTexture(gl,context, R.raw.techo);
		texCoords = new float[]{
				-30f, -30f, 0.0f,  // Vértice inferior izquierdo
				-30f,  30f, 0.0f,  // Vértice superior izquierdo
				30f,   30f, 0.0f,  // Vértice superior derecho
				30f,  -30f, 0.0f   // Vértice inferior derecho
		};
		techo.setvertices(texCoords);

		texCoords = new float[]{
				0.0f, 20.0f,  // A. left bottom (repitiendo la textura 2 veces en eje Y)
				0.0f, 0.0f,  // B. left top
				20.0f, 0.0f,  // C. right top
				20.0f, 20.0f   // D. right bottom (repitiendo la textura 2 veces en eje X)
		};
		techo.setTexCoords(texCoords);

		short faces[] = { 1, 0, 3, 1, 3, 2 };
		techo.setfaces(faces);


		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.855f, 0.5f,  // A. left botom
				0.855f, 0.4f,  // B. left top
				0.94f, 0.4f,  // C. right top
				0.94f, 0.5f   // D. right botom
		};
		cabezaText.setTexCoords(texCoords);
		cabezaText.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.862f, 0.155f,  // A. left botom
				0.862f, 0.1f,  // B. left top
				0.913f, 0.1f,  // C. right top
				0.913f, 0.155f   // D. right botom
		};
		n1Text.setTexCoords(texCoords);
		n1Text.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.627f, 0.155f,  // A. left botom
				0.627f, 0.1f,  // B. left top
				0.678f, 0.1f,  // C. right top
				0.678f, 0.155f   // D. right botom
		};
		n2Text.setTexCoords(texCoords);
		n2Text.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.674f, 0.155f,  // A. left botom
				0.674f, 0.1f,  // B. left top
				0.725f, 0.1f,  // C. right top
				0.725f, 0.155f   // D. right botom
		};
		n3Text.setTexCoords(texCoords);
		n3Text.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.533f, 0.155f,  // A. left botom
				0.533f, 0.1f,  // B. left top
				0.584f, 0.1f,  // C. right top
				0.584f, 0.155f   // D. right botom
		};
		n4Text.setTexCoords(texCoords);
		n4Text.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.909f, 0.155f,  // A. left botom
				0.909f, 0.1f,  // B. left top
				0.960f, 0.1f,  // C. right top
				0.960f, 0.155f   // D. right botom
		};
		n5Text.setTexCoords(texCoords);
		n5Text.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.862f, 0.155f,  // A. left botom
				0.862f, 0.1f,  // B. left top
				0.913f, 0.1f,  // C. right top
				0.913f, 0.155f   // D. right botom
		};
		n6Text.setTexCoords(texCoords);
		n6Text.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.721f, 0.155f,  // A. left botom
				0.721f, 0.1f,  // B. left top
				0.772f, 0.1f,  // C. right top
				0.772f, 0.155f   // D. right botom
		};
		n7Text.setTexCoords(texCoords);
		n7Text.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.909f, 0.155f,  // A. left botom
				0.909f, 0.1f,  // B. left top
				0.960f, 0.1f,  // C. right top
				0.960f, 0.155f   // D. right botom
		};
		n8Text.setTexCoords(texCoords);
		n8Text.loadTexture(gl, context, R.raw.doomhud);


		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.33f, 0.2f,  // A. left botom
				0.33f, 0.11f,  // B. left top
				0.45f, 0.11f,  // C. right top
				0.45f, 0.2f   // D. right botom
		};
		arms.setTexCoords(texCoords);
		arms.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.94f, 0.28f,  // A. left botom
				0.94f, 0.08f,  // B. left top
				0.98f, 0.08f,  // C. right top
				0.98f, 0.28f   // D. right botom
		};
		arma.setTexCoords(texCoords);
		arma.loadTexture(gl, context, R.raw.armas);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.93f, 0.1f,  // A. left botom
				0.93f, 0f,  // B. left top
				1f, 0f,  // C. right top
				1f, 0.1f   // D. right botom
		};
		aux.setTexCoords(texCoords);
		aux.loadTexture(gl, context, R.raw.doomhud);

		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.032f, 0.164f,  // A. left botom
				0.032f, 0.142f,  // B. left top
				0.050f, 0.142f,  // C. right top
				0.050f, 0.164f   // D. right botom
		};
		n1.setTexCoords(texCoords);
		n1.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.048f, 0.142f,  // A. left botom
				0.048f, 0.120f,  // B. left top
				0.066f, 0.120f,  // C. right top
				0.066f, 0.142f   // D. right botom
		};
		n2.setTexCoords(texCoords);
		n2.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.064f, 0.142f,  // A. left botom
				0.064f, 0.120f,  // B. left top
				0.082f, 0.120f,  // C. right top
				0.082f, 0.142f   // D. right botom
		};
		n3.setTexCoords(texCoords);
		n3.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.080f, 0.142f,  // A. left botom
				0.080f, 0.120f,  // B. left top
				0.096f, 0.120f,  // C. right top
				0.096f, 0.142f   // D. right botom
		};
		n4.setTexCoords(texCoords);
		n4.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.096f, 0.142f,  // A. left botom
				0.096f, 0.120f,  // B. left top
				0.112f, 0.120f,  // C. right top
				0.112f, 0.142f   // D. right botom
		};
		n5.setTexCoords(texCoords);
		n5.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.112f, 0.142f,  // A. left botom
				0.112f, 0.120f,  // B. left top
				0.128f, 0.120f,  // C. right top
				0.128f, 0.142f   // D. right botom
		};
		n6.setTexCoords(texCoords);
		n6.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.048f, 0.164f,  // A. left botom
				0.048f, 0.142f,  // B. left top
				0.064f, 0.142f,  // C. right top
				0.064f, 0.164f   // D. right botom
		};
		n7.setTexCoords(texCoords);
		n7.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.048f, 0.164f,  // A. left botom
				0.048f, 0.142f,  // B. left top
				0.064f, 0.142f,  // C. right top
				0.064f, 0.164f   // D. right botom
		};
		n8.setTexCoords(texCoords);
		n8.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n9.setTexCoords(texCoords);
		n9.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n10.setTexCoords(texCoords);
		n10.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n11.setTexCoords(texCoords);
		n11.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.032f, 0.164f,  // A. left botom
				0.032f, 0.142f,  // B. left top
				0.050f, 0.142f,  // C. right top
				0.050f, 0.164f   // D. right botom
		};
		n12.setTexCoords(texCoords);
		n12.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n13.setTexCoords(texCoords);
		n13.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n14.setTexCoords(texCoords);
		n14.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n15.setTexCoords(texCoords);
		n15.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n16.setTexCoords(texCoords);
		n16.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0f, 0.164f,  // A. left botom
				0f, 0.142f,  // B. left top
				0.016f, 0.142f,  // C. right top
				0.016f, 0.164f   // D. right botom
		};
		n17.setTexCoords(texCoords);
		n17.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.079f, 0.164f,  // A. left botom
				0.079f, 0.142f,  // B. left top
				0.096f, 0.142f,  // C. right top
				0.096f, 0.164f   // D. right botom
		};
		n18.setTexCoords(texCoords);
		n18.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.143f, 0.164f,  // A. left botom
				0.143f, 0.142f,  // B. left top
				0.160f, 0.142f,  // C. right top
				0.160f, 0.164f   // D. right botom
		};
		n19.setTexCoords(texCoords);
		n19.loadTexture(gl, context, R.raw.doomhud);
		texCoords = new float[]{ // Texture coords for the above face (NEW)
				0.063f, 0.164f,  // A. left botom
				0.063f, 0.142f,  // B. left top
				0.080f, 0.142f,  // C. right top
				0.080f, 0.164f   // D. right botom
		};
		n20.setTexCoords(texCoords);
		n20.loadTexture(gl, context, R.raw.doomhud);


		gl.glClearDepthf(1.0f);
		gl.glEnable(GL10.GL_DEPTH_TEST);
		gl.glDepthFunc(GL10.GL_LEQUAL);
		gl.glEnable(GL10.GL_BLEND);
		gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_SRC_ALPHA);

		gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_NICEST);
		gl.glShadeModel(GL10.GL_SMOOTH);
		gl.glDisable(GL10.GL_DITHER);

		gl.glEnable(GL10.GL_LIGHTING);

		gl.glEnable(GL10.GL_NORMALIZE);

		light = new Light(gl, GL10.GL_LIGHT0);
		light.setPosition(new float[]{0.0f, 1f, 2f, 0.0f});
		light.setAmbientColor(new float[]{0.5f, 0.5f, 0.5f});
		light.setDiffuseColor(new float[]{1f, 1, 1});

	}

	@Override
	public void onDrawFrame(GL10 gl) {
		// 3D Scene  ----------------------------------
		setPerspectiveProjection(gl);

		gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);


		gl.glMatrixMode(GL10.GL_MODELVIEW);
		gl.glLoadIdentity();
		float radians = (float) Math.toRadians(angle*10);
		float cosAngle = (float) Math.cos(radians);
		float sinAngle = (float) Math.sin(radians);

		if(zCam < 3.6){
			gl.glTranslatef(0.0f, 0.0f, -4.0f -zCam);
			float eyeX = 0.0f;
			float eyeY = 0.0f;
			float eyeZ = 5.0f;

			float centerX = 0.0f;
			float centerY = 0.0f;
			float centerZ = 0.0f;
			float upX = 0.0f;
			float upY = 1.0f;
			float upZ = 0.0f;

			float diffX = centerX - eyeX;
			float diffZ = centerZ - eyeZ;

			centerX = eyeX + diffX * cosAngle - diffZ * sinAngle;
			centerZ = eyeZ + diffX * sinAngle + diffZ * cosAngle ;
			GLU.gluLookAt(gl, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);
		}
		else{
			gl.glTranslatef(0.7f, -0.8f, -4.0f);
			gl.glRotatef(45, -0.1f, 1.6f, 0.0f);
			gl.glRotatef(45, 0.0f, 1f, 0.0f);
			gl.glTranslatef(0f, 0.5f, -0.8f);
		}


		transformedLightPosition[0] = originalLightPosition[0] * cosAngle + originalLightPosition[2] * sinAngle;
		transformedLightPosition[1] = originalLightPosition[1];
		transformedLightPosition[2] = originalLightPosition[0] * sinAngle + originalLightPosition[2] * cosAngle;
		transformedLightPosition[3] = originalLightPosition[3];


		light.setPosition(transformedLightPosition);



		if(zCam < 3.6){
			gl.glPushMatrix();
			gl.glScalef(0.5f, 0.5f, 0.5f);
			float offsetY = (float) Math.sin(tiempo) * 0.5f;
			gl.glTranslatef(0, offsetY, 0);
			gl.glRotatef(-90.0f, 1f, 0.0f, 0.0f);
			gl.glBindTexture(GL10.GL_TEXTURE_2D, object3D.getTextureID());
			object3D.draw(gl);
			gl.glPopMatrix();

			tiempo += 0.05f;
		}else{
			gl.glPushMatrix();
			gl.glScalef(0.5f, 0.5f, 0.5f);
			float offsetY = (float) Math.sin(tiempo) * 0.5f;
			gl.glTranslatef(0, offsetY, 0);
			gl.glRotatef(-90.0f, 1f, 0.0f, 0.0f);
			gl.glRotatef(-90.0f, 0f, 0.0f, 1.0f);
			gl.glBindTexture(GL10.GL_TEXTURE_2D, object3D.getTextureID());
			object3D.draw(gl);
			gl.glPopMatrix();

			tiempo += 0.05f;
		}

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.5f, 0.5f);
		gl.glTranslatef(1.7f, 0, -4.9f);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		puerta.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(8, 0, -2);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(-8, 0, -2);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(-8, 0, 6);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(8, 0, 6);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(-8, 0, 14);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(8, 0, 14);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(-8, 0, 22);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f, 0.3f, 0.5f);
		gl.glTranslatef(8, 0, 22);
		gl.glBindTexture(GL10.GL_TEXTURE_2D, colum.getTextureID());
		colum.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f,0.5f,0.5f);
		gl.glTranslatef(0,-2f,15);
		gl.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
		suelo.draw(gl);
		gl.glPopMatrix();


		gl.glPushMatrix();
		gl.glScalef(0.5f,0.5f,0.5f);
		gl.glTranslatef(0,2f,15);
		gl.glRotatef(+90.0f, 1.0f, 0.0f, 0.0f);
		techo.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f,0.5f,0.5f);
		gl.glTranslatef(-8,0f,15);
		gl.glRotatef(+90.0f, 0f, 1.0f, 0.0f);
		pared1.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f,0.5f,0.5f);
		gl.glTranslatef(8,0f,15);
		gl.glRotatef(-90.0f, 0f, 1.0f, 0.0f);
		pared2.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f,0.5f,0.5f);
		gl.glTranslatef(0,0f,-5);
		pared3.draw(gl);
		gl.glPopMatrix();

		gl.glPushMatrix();
		gl.glScalef(0.5f,0.5f,0.5f);
		gl.glTranslatef(0,0f,25);
		gl.glRotatef(-180.0f, 0f, 1.0f, 0.0f);
		pared4.draw(gl);
		gl.glPopMatrix();


		// HUD ----------------------------------
		setOrthographicProjection(gl);
		if(zCam < 3.6) {

			gl.glPushMatrix();
			gl.glTranslatef(-0.2f, -3.6f, 10);
			gl.glScalef(1f, 1.3f, 1f);
			barraPrincText.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-0.15f, -3.55f, 0);
			gl.glScalef(0.1f, 1f, 1f);
			cabezaText.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-4.65f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n1Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-4.15f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n2Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-3.25f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n3Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-2.75f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n4Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-2.25f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n5Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(0.75f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n6Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(1.25f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n7Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(1.75f, -3.5f, 0);
			gl.glScalef(0.05f, 0.6f, 1f);
			n8Text.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-1.25f, -3.63f, 0);
			gl.glScalef(0.12f, 1f, 1f);
			arms.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(0f, -2.56f, 0);
			gl.glScalef(0.2f, 2.1f, 1f);
			arma.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.85f, -3.6f, 0);
			gl.glScalef(0.12f, 1.3f, 1f);
			aux.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-1.65f, -3.43f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n1.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-1.25f, -3.43f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n2.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-0.85f, -3.43f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n3.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-1.65f, -3.63f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n4.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-1.25f, -3.63f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n5.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(-0.85f, -3.63f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n6.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(3.53f, -3.35f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n7.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(3.83f, -3.35f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n8.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(3.83f, -3.5f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n9.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(3.83f, -3.7f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n10.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(3.83f, -3.9f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n11.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.25f, -3.35f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n12.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.55f, -3.35f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n13.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.85f, -3.35f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n14.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.85f, -3.5f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n15.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.85f, -3.7f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n16.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.85f, -3.9f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n17.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.55f, -3.5f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n18.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.55f, -3.7f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n19.draw(gl);
			gl.glPopMatrix();

			gl.glPushMatrix();
			gl.glTranslatef(4.55f, -3.9f, 0);
			gl.glScalef(0.03f, 0.3f, 1f);
			n20.draw(gl);
			gl.glPopMatrix();
		}
	}

	private void setPerspectiveProjection(GL10 gl) {
		gl.glClearDepthf(1.0f);            // Set depth's clear-value to farthest
		gl.glEnable(GL10.GL_DEPTH_TEST);   // Enables depth-buffer for hidden surface removal
		gl.glDepthFunc(GL10.GL_LEQUAL);    // The type of depth testing to do
		gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_NICEST);  // nice perspective view
		gl.glShadeModel(GL10.GL_SMOOTH);   // Enable smooth shading of color
		gl.glDisable(GL10.GL_DITHER);      // Disable dithering for better performance
		gl.glDepthMask(true);  // disable writes to Z-Buffer

		gl.glMatrixMode(GL10.GL_PROJECTION); // Select projection matrix
		gl.glLoadIdentity();                 // Reset projection matrix

		// Use perspective projection
		GLU.gluPerspective(gl, 60, (float) width / height, 0.05f, 100.f);

		gl.glMatrixMode(GL10.GL_MODELVIEW);  // Select model-view matrix
		gl.glLoadIdentity();                 // Reset
	}

	private void setOrthographicProjection(GL10 gl){
		gl.glMatrixMode(GL10.GL_PROJECTION);
		gl.glEnable(GL10.GL_DEPTH_TEST);

		gl.glLoadIdentity();
		gl.glOrthof(-5,5,-4,4,-100,100);
		gl.glDepthMask(false);  // disable writes to Z-Buffer
		gl.glDisable(GL10.GL_DEPTH_TEST);  // disable depth-testing
		gl.glEnable(GL10.GL_BLEND);
		gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_SRC_ALPHA);

		gl.glMatrixMode(GL10.GL_MODELVIEW);
		gl.glLoadIdentity();
	}

	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		// Define the Viewport
		this.width=width;
		this.height=height;

		gl.glViewport(0, 0, width, height);
	}


}
